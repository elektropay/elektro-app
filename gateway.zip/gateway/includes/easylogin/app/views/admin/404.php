<?php echo View::make('admin.header')->render() ?>

<h3 class="page-header"><?php _e('admin.404') ?></h3>
<p><?php _e('admin.page_not_found') ?></p>

<?php echo View::make('admin.footer')->render() ?>
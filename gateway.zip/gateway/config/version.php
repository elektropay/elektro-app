<?php

$config['opengateway_version'] = '1.993';
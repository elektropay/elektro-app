<?php

$config['protocol'] = 'mail';
$config['wordwrap'] = TRUE;
$config['validate'] = TRUE;
$config['mailtype'] = 'html';
$config['charset'] = 'iso-8859-1';